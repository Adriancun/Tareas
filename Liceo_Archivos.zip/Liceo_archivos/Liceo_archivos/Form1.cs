namespace Liceo_archivos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncrear_Click(object sender, EventArgs e)
        {
            string texto = txtnombre.Text;
            string ruta = @"C:\Users\DELL\Documents\visual estudio_2\" + texto + ".txt";
            using(StreamWriter sw = new StreamWriter(texto))
            {
                sw.WriteLine("hola papu");
            }
            MessageBox.Show("Se Creo correctamente");
        }

        private void txtComentario_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
            Application.Exit(); //cerrar mi programa
        }
    }
}